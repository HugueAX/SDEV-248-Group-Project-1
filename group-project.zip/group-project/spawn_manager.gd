extends Node

# ─────────────────────────────────────────────
#  EXPORTS — assign in Inspector
# ─────────────────────────────────────────────
@export var spider_scene: PackedScene
@export var ghost_scene:  PackedScene
@export var demon_scene:  PackedScene
@export var player_path:  NodePath
@export var map_size:     Vector2 = Vector2(1920, 1080)

# 1 = Forest, 2 = Graveyard, 3 = Dungeon
@export var level: int = 1

# ─────────────────────────────────────────────
#  CONSTANTS
# ─────────────────────────────────────────────
const FOREST_COUNT:    int   = 8
const GRAVEYARD_COUNT: int   = 10
const MIN_SPAWN_DIST:  float = 200.0   # Can't spawn within this range of player
const DUNGEON_SPAWN_COUNT: int = 3     # Enemies per boss attack in dungeon

var player: Node2D = null

func _ready() -> void:
	player = get_node(player_path)

	match level:
		1: _spawn_forest()
		2: _spawn_graveyard()
		3: _connect_boss_signal()


# ─────────────────────────────────────────────
#  LEVEL SPAWNERS
# ─────────────────────────────────────────────
func _spawn_forest() -> void:
	for i in FOREST_COUNT:
		_spawn_enemy(spider_scene)

func _spawn_graveyard() -> void:
	for i in GRAVEYARD_COUNT:
		var scene = spider_scene if randf() < 0.5 else ghost_scene
		_spawn_enemy(scene)

func _connect_boss_signal() -> void:
	# Find the boss in the scene and connect its attack signal
	var boss = get_tree().get_first_node_in_group("boss")
	if boss and boss.has_signal("boss_attacked"):
		boss.boss_attacked.connect(_on_boss_attacked)

func _on_boss_attacked() -> void:
	# Spawn a random mix of enemies each time the boss attacks
	for i in DUNGEON_SPAWN_COUNT:
		var roll: float = randf()
		if roll < 0.33:
			_spawn_enemy(spider_scene)
		elif roll < 0.66:
			_spawn_enemy(ghost_scene)
		else:
			_spawn_enemy(demon_scene)


# ─────────────────────────────────────────────
#  SHARED SPAWN HELPER
# ─────────────────────────────────────────────
func _spawn_enemy(scene: PackedScene) -> void:
	if scene == null or player == null:
		return

	var spawn_pos: Vector2 = _get_valid_spawn_position()
	var enemy = scene.instantiate()
	get_tree().current_scene.add_child(enemy)
	enemy.global_position = spawn_pos

func _get_valid_spawn_position() -> Vector2:
	var pos: Vector2
	var attempts: int = 0

	while attempts < 50:
		pos = Vector2(
			randf_range(100, map_size.x - 100),
			randf_range(100, map_size.y - 100)
		)
		if pos.distance_to(player.global_position) >= MIN_SPAWN_DIST:
			return pos
		attempts += 1

	# Fallback — just put it far from center if we run out of attempts
	return Vector2(100, 100)
