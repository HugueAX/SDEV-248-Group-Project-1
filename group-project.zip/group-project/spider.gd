extends CharacterBody2D

@export var speed: float = 50.0

@onready var anim: AnimationPlayer = $AnimationPlayer

var player: Node2D = null

func _ready() -> void:
	player = get_tree().get_first_node_in_group("player")
	anim.play("walk")

func _physics_process(_delta: float) -> void:
	if player == null:
		return

	var direction: Vector2 = (player.global_position - global_position).normalized()

	# Face the player
	if player.global_position.x < global_position.x:
		scale.x = -1
	else:
		scale.x = 1

	velocity = direction * speed
	move_and_slide()

func take_damage(_amount: int) -> void:
	queue_free()
